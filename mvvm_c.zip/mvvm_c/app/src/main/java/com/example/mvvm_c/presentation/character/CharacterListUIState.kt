package com.example.mvvm_c.presentation.character

import android.icu.text.CaseMap

data class CharacterListUIState(
    val title: String = "Personajes de Ricky and Morty",
    val isLoading: Boolean = false
)