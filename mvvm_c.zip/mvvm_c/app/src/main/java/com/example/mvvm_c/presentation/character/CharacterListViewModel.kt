package com.example.mvvm_c.presentation.character

import androidx.compose.runtime.MutableState
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class CharacterListViewModel : ViewModel(){
    private val _viState = MutableStateFlow(CharacterListUIState()
    )
    val uiState: StateFlow<CharacterListUIState> =
        _uiState.asStateFlow()
}